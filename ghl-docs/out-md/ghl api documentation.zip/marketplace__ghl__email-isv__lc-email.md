# https://marketplace.gohighlevel.com/docs/ghl/email-isv/lc-email

Version: 1.0

# LC Email

Documentation for Email ISV API

## Authentication[​](#authentication "Direct link to Authentication")

*   HTTP: Bearer Auth
*   HTTP: Bearer Auth
*   HTTP: Bearer Auth

Use the Access Token generated with user type as Sub-Account (OR) Private Integration Token of Sub-Account.

Security Scheme Type:

http

HTTP Authorization Scheme:

bearer

Bearer format:

JWT

Use the Access Token generated with user type as Sub-Account (OR) Private Integration Token of Sub-Account.

Security Scheme Type:

http

HTTP Authorization Scheme:

bearer

Bearer format:

JWT

Use the Access Token generated with user type as Agency (OR) Private Integration Token of Agency.

Security Scheme Type:

http

HTTP Authorization Scheme:

bearer

Bearer format:

JWT
