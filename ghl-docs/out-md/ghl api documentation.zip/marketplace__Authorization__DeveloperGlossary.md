# https://marketplace.gohighlevel.com/docs/Authorization/DeveloperGlossary

*   **Developer's Marketplace:** The Developer's Marketplace is a platform within GoHighLevel that allows developers to build and integrate their applications and tools using the GoHighLevel API. [GoHighLevel Developer Documentation](https://marketplace.gohighlevel.com/docs)
    
*   **API (Application Programming Interface):** An API is a set of rules and protocols that allows different software applications to communicate with each other. In the Developer's Marketplace context, the GoHighLevel API enables developers to access and interact with GoHighLevel's features and data.
    
*   **Access Token:** An Access Token is a credential an app uses to access protected resources for a user or account. In the Developer's Marketplace, developers obtain an Access Token through the OAuth process, which allows their app to make authenticated API requests to GoHighLevel. The Access Token is usually included in the Authorization header of API requests.
    
*   **AppID:** The unique identifier for your marketplace application. You can find it below the app name.
    
*   **Conversation Provider ID:** The unique identifier for the type of provider a user installs. You can find it under the name of the conversation provider if you have created one for your app.
    
*   **Refresh Token:** A Refresh Token is a credential that can be used to obtain a new Access Token without requiring the user to reauthorize the app. It provides a longer-lasting authorization mechanism and helps maintain continuous access to GoHighLevel resources. When an Access Token expires, the Refresh Token can be used to obtain a new one.
    
*   **OAuth (Open Authorization):** OAuth is an industry-standard protocol that enables secure app authorization and authentication. It allows users to grant permission to apps to access their GoHighLevel data without sharing their login credentials. OAuth involves an authorization process where users are redirected to GoHighLevel to authenticate and grant access to the app. [OAuth 2.0 Introduction](https://oauth.net/2/)
    
*   **Redirect URI:** A Redirect URI is the URL that GoHighLevel will send users after authorizing the app's access. During the OAuth process, users are redirected to the app with an authorization code or access token appended to the Redirect URI after granting permission. [OAuth 2.0 Redirect URI](https://www.oauth.com/oauth2-servers/redirect-uris/)
    
*   **Authorization Code:** In the OAuth process, an Authorization Code is a short-lived credential obtained after a user successfully authorizes an app. The app exchanges this code for an Access Token and Refresh Token. [OAuth 2.0 Authorization Code Grant](https://www.oauth.com/oauth2-servers/access-tokens/authorization-code-request/)
    
*   **Scopes:** Scopes define the specific permissions and access rights an app requires to interact with GoHighLevel. When creating an app, developers specify the necessary scopes that align with their app's functionalities. Scopes can include reading, writing, or managing permissions for different resources within GoHighLevel. [OAuth 2.0 Scopes](https://oauth.net/2/scope/) and this resource is for [Gohighlevel's OAuth Scopes.](https://marketplace.gohighlevel.com/docs/Authorization/Scopes)
    
*   **Endpoint:** An endpoint is a specific URL or URI representing an API resource or functionality. GoHighLevel's API exposes various endpoints that developers can access to perform specific actions or retrieve specific data.
    
*   **Status Code:** A status code is a three-digit number returned by the server to indicate the outcome of an HTTP request. Common status codes include 200 (OK), 400 (Bad Request), 401 (Unauthorized), and 422 (Unprocessable Entity). [HTTP Status Codes](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status)
    
*   **Distribution Type:** Distribution Type refers to how an app is distributed or made available to GoHighLevel users. It can be either Agency or Sub Account. Agency distribution allows the app to be used by all locations within an agency account, while Sub Account distribution limits usage to specific sub-accounts or individual locations.
    
*   **Location ID:** Location ID is a unique identifier assigned to a specific location within a GoHighLevel account. It is used to differentiate and manage access at the location level.
    
*   **Company ID:** Company ID is a unique identifier assigned to a GoHighLevel company or account. It helps differentiate and manage access at the company level.
    
*   **Live Server:** Live Server refers to the actual production environment where the app interacts with GoHighLevel's API and real user data. It is the server where the app is deployed and accessible by users.
    
*   **SDK (Software Development Kit):** An SDK is a set of tools, libraries, and documentation developers use to build applications for a specific platform or framework. GoHighLevel provides an SDK that facilitates the integration of custom apps with its API.
    
*   **Authorization Header:** The Authorization Header is an HTTP header that includes authentication credentials in API requests, such as an Access Token. It typically takes the form "Authorization: Bearer `Access-Token`". [Understand the Authorization Header](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Headers/Authorization)
    
*   **API Key:** An API Key is a unique identifier or code provided to developers granting API access. It serves as a form of authentication when making API requests.
    
*   **Callback URL:** A Callback URL is where an app expects to receive callbacks or responses. In the Developer's Marketplace context, the Callback URL is the endpoint that receives the authorization code or access token after the user grants permission during the OAuth process. [Learn more about Callback URLs](https://oauth.net/2/redirect-uris/)
    
*   **JSON (JavaScript Object Notation):** JSON is a lightweight data-interchange format that is easy for humans to read and write and for machines to parse and generate. It is commonly used for structuring data in API requests and responses. [Introduction to JSON](https://www.json.org/json-en.html)
    
*   **Parameters:** Parameters are additional values included in an API request to provide specific instructions or filter the desired data. Parameters can be used to specify search criteria, sorting preferences, or pagination options. [Understanding API Parameters](https://cloud.google.com/apigee)
    
*   **Pagination:** Pagination is dividing a large data set into smaller, more manageable parts called pages. API responses often include pagination information, such as the number of items per page and the total number of pages, allowing developers to retrieve data incrementally. [Implementing Pagination](https://www.moesif.com/blog/technical/api-design/REST-API-Design-Filtering-Sorting-and-Pagination/)
    
*   **Rate Limiting:** Rate Limiting is a mechanism APIs use to restrict client or user's requests within a specific period. It helps maintain API performance and prevent abuse.
    
*   **Webhooks:** Webhooks are HTTP callbacks or notifications sent from one application to another when a specific event or trigger occurs. In the Developer's Marketplace context, developers can configure webhooks to receive real-time updates or data from GoHighLevel, such as new leads or contact information.
    
*   **Event:** An Event refers to a specific occurrence or action within an application or system. In the context of webhooks, events are triggers that prompt sending a webhook notification.
    
*   **Request:** A request is a communication made by an app to the GoHighLevel API. It includes the HTTP method (e.g., GET, POST), the URL or endpoint, headers, and required parameters or data. [HTTP Request Methods](https://www.tutorialspoint.com/http/http_methods.htm)
    
*   **Response:** A response is the server's reply to a request made by an app. It contains the requested data, an acknowledgment of the action performed, and an appropriate status code. [HTTP Response Status Codes](https://developer.mozilla.org/en-US/docs/Web/HTTP/Reference/Status)
    
*   **GET**: GET is an HTTP method to retrieve server data. It is commonly used for fetching resources or information from APIs. [GET method in HTTP](https://www.w3schools.com/tags/ref_httpmethods.asp)
    
*   **POST**: POST is an HTTP method to submit data to a server. It is typically used for creating new resources or sending data to be processed by APIs. [POST method in HTTP](https://www.w3schools.com/tags/ref_httpmethods.asp)
    
*   **PUT**: PUT is an HTTP method to update or replace existing data on a server. It replaces the entire resource with the new data provided in the request. [PUT method in HTTP](https://www.w3schools.com/tags/ref_httpmethods.asp)
    
*   **DELETE**: DELETE is an HTTP method that removes or deletes a resource from a server. It instructs the server to delete the specified resource. [DELETE method in HTTP](https://www.w3schools.com/tags/ref_httpmethods.asp)
    
*   **Front-End Development:** Front-End Development involves building the user-facing components of a software application. It typically includes HTML, CSS, and JavaScript developers to create interactive and visually appealing interfaces.
    
*   **Back-End Development:** Back-End Development focuses on the server-side components of a software application. It involves implementing the logic, data storage, and processing necessary to support the application's functionality.
    

* * *
