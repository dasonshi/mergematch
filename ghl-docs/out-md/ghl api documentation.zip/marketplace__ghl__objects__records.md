# https://marketplace.gohighlevel.com/docs/ghl/objects/records

Custom objects are completely customizable objects that allow you to store and manage information tailored to your unique business needs. With custom objects, you can create custom fields, establish relationships, and integrate them into workflows, providing flexibility beyond standard objects like Contacts, Opportunities or Companies.

[

## 📄️ Get Record By Id

Allows you to get a Standard Object like business and custom object record by Id

](/docs/ghl/objects/get-record-by-id)

[

## 📄️ Update Record

Update a Custom Object Record by Id. Supported Objects are business and custom objects. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0/87cpx-376296

](/docs/ghl/objects/update-object-record)

[

## 📄️ Delete Record

Delete Record By Id . Supported Objects are business and custom objects.

](/docs/ghl/objects/delete-object-record)

[

## 📄️ Create Record

Create a Custom Object Record. Supported Objects business and custom objects. Documentation Link - https://doc.clickup.com/8631005/d/h/87cpx-277156/93bf0c2e23177b0/87cpx-376296

](/docs/ghl/objects/create-object-record)
