# https://marketplace.gohighlevel.com/docs/ghl/opportunities/opportunities

Documentation for Opportunities API

[

## 📄️ Get Opportunity

Get Opportunity

](/docs/ghl/opportunities/get-opportunity)

[

## 📄️ Delete Opportunity

Delete Opportunity

](/docs/ghl/opportunities/delete-opportunity)

[

## 📄️ Update Opportunity

Update Opportunity

](/docs/ghl/opportunities/update-opportunity)

[

## 📄️ Update Opportunity Status

Update Opportunity Status

](/docs/ghl/opportunities/update-opportunity-status)

[

## 📄️ Upsert Opportunity

Upsert Opportunity

](/docs/ghl/opportunities/upsert-opportunity)

[

## 📄️ Create Opportunity

Create Opportunity

](/docs/ghl/opportunities/create-opportunity)
