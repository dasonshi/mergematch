# https://marketplace.gohighlevel.com/docs/ghl/contacts/get-all-tasks

# Get all Tasks

GET 

## https://services.leadconnectorhq.com/contacts/:contactId/tasks

Get all Tasks

### Requirements

#### Scope(s)

`contacts.readonly`

#### Auth Method(s)

`OAuth Access Token``Private Integration Token`

#### Token Type(s)

`Sub-Account Token`

## Request[​](#request "Direct link to Request")

### Header Parameters

**Version** stringrequired

**Possible values:** \[`2021-07-28`\]

API Version

### Path Parameters

**contactId** stringrequired

Contact Id

Example: sx6wyHhbFdRXh302LLNR

## Responses[​](#responses "Direct link to Responses")

*   200
*   400
*   401

Successful response

*   application/json

*   Schema
*   Example (auto)

**Schema**

**tasks** object\[\]

*   Array \[
    

**id** string

Example:`lJpzYrWdpkC2hX6t2yue`

**title** string

Example:`test`

**body** string

Example:`testing`

**assignedTo** string

Example:`tesTUcmRxWrjqzJS8EjkxNKting`

**dueDate** string

Example:`2021-07-08T02:30:00.000Z`

**completed** boolean

Example:`true`

**contactId** string

Example:`lJpzYrWdpkC2hX6t2yue`

*   \]
    

```
{  "tasks": [    {      "id": "lJpzYrWdpkC2hX6t2yue",      "title": "test",      "body": "testing",      "assignedTo": "tesTUcmRxWrjqzJS8EjkxNKting",      "dueDate": "2021-07-08T02:30:00.000Z",      "completed": true,      "contactId": "lJpzYrWdpkC2hX6t2yue"    }  ]}
```

Bad Request

*   application/json

*   Schema
*   Example (auto)

**Schema**

**statusCode** number

Example:`400`

**message** string

Example:`Bad Request`

```
{  "statusCode": 400,  "message": "Bad Request"}
```

Unauthorized

*   application/json

*   Schema
*   Example (auto)

**Schema**

**statusCode** number

Example:`401`

**message** string

Example:`Invalid token: access token is invalid`

**error** string

Example:`Unauthorized`

```
{  "statusCode": 401,  "message": "Invalid token: access token is invalid",  "error": "Unauthorized"}
```

## Share your feedback

★★★★★

#### Authorization: Authorization

**name:** [Authorization](/docs/ghl/contacts/contacts-api#authentication)**type:** http**scopes:** `contacts.readonly`**scheme:** bearer**bearerFormat:** JWT**in:** header**description:** Use the Access Token generated with user type as Sub-Account (OR) Private Integration Token of Sub-Account.

*   curl
*   nodejs
*   python
*   php
*   java
*   go
*   ruby
*   powershell

*   CURL

```
curl -L 'https://services.leadconnectorhq.com/contacts/:contactId/tasks' \-H 'Accept: application/json' \-H 'Authorization: Bearer <TOKEN>'
```

Request Collapse all

Base URL

Edit

https://services.leadconnectorhq.com

Auth

Bearer Token

Parameters

contactId — pathrequired

Version — headerrequired

\---2021-07-28

Send API Request

ResponseClear

Click the `Send API Request` button above and see the response here!
